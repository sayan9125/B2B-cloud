package com.h2h.webfetch;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.h2h.conn.DB_Conn;
import com.h2h.getset.invoiceBin;

@WebServlet("/Search_cust_num")
public class Search_cust_num extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public Search_cust_num() {
        super();
       
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.addHeader("Access-Control-Allow-Origin","*");
		int cust_number=Integer.parseInt(request.getParameter("cust_number"));
		DB_Conn db=new DB_Conn();
		 ArrayList<invoiceBin> data=new ArrayList<invoiceBin>();
		try {
			data=db.searchbyCustNumber(cust_number);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String reJson=new Gson().toJson(data);
        response.setStatus(200);
        response.getWriter().write(reJson);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
