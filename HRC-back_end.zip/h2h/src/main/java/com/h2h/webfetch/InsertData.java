package com.h2h.webfetch;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.h2h.conn.DB_Conn;
import com.h2h.getset.invoiceBin;



@WebServlet("/InsertData")
public class InsertData extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public InsertData() {
        super();
        
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setHeader("Access-Control-Allow-Origin","*");
		    DB_Conn data=new DB_Conn();
			int i=0;
			String business_code=request.getParameter("business_code");
			String cust_number=request.getParameter("cust_number");
			String clear_date=request.getParameter("clear_date");
			double buisness_year=Double.parseDouble(request.getParameter("buisness_year"));
			double doc_id=Double.parseDouble(request.getParameter("doc_id"));
			String posting_date=request.getParameter("posting_date");
			int document_create_date=Integer.parseInt(request.getParameter("document_create_date"));
			double due_in_date=Double.parseDouble(request.getParameter("due_in_date"));
			String invoice_currency=request.getParameter("invoice_currency");
			String document_type=request.getParameter("document_type");
			double posting_id=Double.parseDouble(request.getParameter("posting_id"));
			double total_open_amount=Double.parseDouble(request.getParameter("total_open_amount"));
			double baseline_create_date=Double.parseDouble(request.getParameter("baseline_create_date"));
			String cust_payment_terms=request.getParameter("cust_payment_terms");
			double invoice_id=Double.parseDouble(request.getParameter("invoice_id"));

			try {
				i=data.insertData(new invoiceBin(business_code,cust_number,clear_date,buisness_year,doc_id,posting_date,document_create_date,due_in_date,invoice_currency,document_type,posting_id,total_open_amount,baseline_create_date,cust_payment_terms,invoice_id));
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(i==0)
			{
				response.getWriter().append("Error ");
				response.setStatus(400);
			}else
				response.getWriter().append("Success ");
			response.setStatus(200);


	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
	}

}
