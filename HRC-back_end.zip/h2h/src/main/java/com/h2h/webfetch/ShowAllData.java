package com.h2h.webfetch;

import java.io.IOException;
import java.sql.SQLException;
import java.util.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.h2h.conn.DB_Conn;
import com.h2h.getset.invoiceBin;

@WebServlet("/ShowAllData")
public class ShowAllData extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public ShowAllData() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.addHeader("Access-Control-Allow-Origin","*");
		DB_Conn db=new DB_Conn();
	    ArrayList<invoiceBin> data=new ArrayList<invoiceBin>();
	       
	    try {
			data=db.showAll();
//	    	System.out.println("ShowAll");
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("error");
		}
	      
	         String reJson=new Gson().toJson(data);
	         response.setStatus(200);
	         response.getWriter().write(reJson);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
