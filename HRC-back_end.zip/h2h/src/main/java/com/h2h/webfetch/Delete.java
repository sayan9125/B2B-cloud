package com.h2h.webfetch;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.h2h.conn.DB_Conn;

/**
 * Servlet implementation class deleteInvoice
 */
@WebServlet("/DeleteInvoice")
public class Delete extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public Delete() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setHeader("Access-Control-Allow-Origin","*");
		int id =Integer.parseInt(request.getParameter("id"));
		DB_Conn db=new DB_Conn();
		try {
			db.deleteUser(id);
			response.getWriter().append("Success");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			response.getWriter().append("Error");
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			response.getWriter().append("Error");
		}
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
