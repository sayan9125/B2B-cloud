package com.h2h.webfetch;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.h2h.conn.DB_Conn;
import com.h2h.getset.invoiceBin;

@WebServlet("/AdvancedSearched")
public class AdvancedSearched extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
    public AdvancedSearched() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		ArrayList<invoiceBin> data=new ArrayList<invoiceBin>();
		response.setHeader("Access-Control-Allow-Origin","*");
		int cust_number=Integer.parseInt(request.getParameter("cust_number"));
		String doc_id=request.getParameter("doc_id");
		String buisness_year=request.getParameter("buisness_year");
		String invoice_id=request.getParameter("invoice_id");
	    DB_Conn db=new DB_Conn();
	    try {
			data=db.advancedSearch(doc_id, invoice_id, buisness_year, cust_number);
//			response.getWriter().append("Succes");
			
			String reJson=new Gson().toJson(data);
	        response.setStatus(200);
	        response.getWriter().write(reJson);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			response.getWriter().append("Error1");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			response.getWriter().append(e+"");
		}
	    
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
