package com.h2h.conn;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.h2h.getset.invoiceBin;


public class DB_Conn {
	private String url="jdbc:mysql://localhost:3306/grey_goose";
	private String user="root";
	private String pass="root";
	private String jdbcDriver="com.mysql.jdbc.Driver";
	
	private String showAllStudent="SELECT * FROM grey_goose.new_dataset";
	private String insert ="INSERT  INTO `new_dataset`(`sl_no`,`business_code`,`cust_number`,`clear_date`,`buisness_year`,`id`,`posting_date`,`document_create_date`,`due_in_date`,`invoice_currency`,`document_type`,`posting_id`,`total_open_amount`,`baseline_create_date`,`cust_payment_terms`,`invoice_id`) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
	private String selectByCustNumber="SELECT * FROM new_dataset WHERE cust_number=";
	private String DeleteUserBy="DELETE FROM new_dataset WHERE sl_no=?;";
	private String update="UPDATE new_dataset SET cust_payment_terms=?,invoice_currency=? WHERE sl_no=?";
	private String advancedSearched="SELECT * FROM  new_dataset WHERE (id=? AND invoice_id=? AND cust_number=? AND buisness_year=?);";
	
	public Connection getCon() throws ClassNotFoundException
	{
		Connection con=null;
		Class.forName(jdbcDriver);
		try {
			con=DriverManager.getConnection(url,user,pass);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return con;
	}
//	private int id;
//	private String business_code;
//	private int cust_number;
//	private String clear_date;
//	private String buisness_year;
//	private String doc_id;
//	private String posting_date;
//	private String document_create_date;
//	private String due_in_date;
//	private String invoice_currency;
//	private String document_type;
//	private int posting_id;
//	private double total_open_amount;
//	private String baseline_create_date;
//	private String cust_payment_terms;
//	private String invoice_id;
	public ArrayList<invoiceBin> showAll() throws SQLException
	{
		ArrayList<invoiceBin> data=new ArrayList<invoiceBin>();
		
		try {
			Connection con=getCon();
			
			
			ResultSet result= con.createStatement().executeQuery(showAllStudent);
			
			while(result.next())
			{
//				System.out.println(Integer.parseInt(result.getString(1)));

				data.add(new invoiceBin(result.getString(1),result.getString(2),result.getString(4),Double.parseDouble(result.getString(5)),Double.parseDouble(result.getString(6)),result.getString(7),Integer.parseInt(result.getString(8)),Double.parseDouble(result.getString(10)),result.getString(11),result.getString(12),Double.parseDouble(result.getString(13)),Double.parseDouble(result.getString(15)),Double.parseDouble(result.getString(16)),result.getString(17),Double.parseDouble(result.getString(18))));
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return data;
		
	}
	public int insertData(invoiceBin temp) throws SQLException
	{
	        try {
				Connection con=getCon();
				PreparedStatement preparedStatement=con.prepareStatement(insert);
			    preparedStatement.setInt(1,(showAll()).size()+1);
			    preparedStatement.setString(2,temp.getBusiness_code());
			    preparedStatement.setString(3,temp.getCust_number());
			    preparedStatement.setString(4,temp.getClear_date());
			    preparedStatement.setDouble(5,temp.getBuisness_year());
			    preparedStatement.setDouble(6, temp.getDoc_id());
			    preparedStatement.setString(7,temp.getPosting_date());
			    preparedStatement.setInt(8, temp.getDocument_create_date());
			    preparedStatement.setDouble(9, temp.getDue_in_date());
			    preparedStatement.setString(10, temp.getInvoice_currency());
			    preparedStatement.setString(11, temp.getDocument_type());
			    preparedStatement.setDouble(12, temp.getPosting_id());
			    preparedStatement.setDouble(13,temp.getTotal_open_amount());
			    preparedStatement.setDouble(14, temp.getBaseline_create_date());
			    preparedStatement.setString(15, temp.getCust_payment_terms());
			    preparedStatement.setDouble(16, temp.getInvoice_id());
				System.out.println(preparedStatement);
			    preparedStatement.executeUpdate();
			    return 1;
		     } catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return 0;
			}
		
	
	}
	public void updataData(int id,String invoice_currency,String cust_payment_terms) throws ClassNotFoundException, SQLException
	{
		
		Connection con=getCon();
		PreparedStatement preparedStatement=con.prepareStatement(update);
		preparedStatement.setString(1,cust_payment_terms);
		preparedStatement.setString(2,invoice_currency);
		preparedStatement.setInt(3, id);
		System.out.println(preparedStatement);
		preparedStatement.executeUpdate();
	
		
	}
	
	public void deleteUser(int id) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection con=getCon();
		PreparedStatement preparedStatement=con.prepareStatement(DeleteUserBy);
		preparedStatement.setInt(1, id);
		System.out.println(preparedStatement);
		preparedStatement.executeUpdate();
		
	}
	
	public ArrayList<invoiceBin> advancedSearch(String doc_id, String invoice_id, String buisness_year, int cust_number) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection con=getCon();
		
		ArrayList<invoiceBin> data=new ArrayList<invoiceBin>();
		String sql="SELECT * FROM  winter_internship WHERE (doc_id="+doc_id+" AND invoice_id="+invoice_id+" AND cust_number="+cust_number +" AND buisness_year="+buisness_year+");";
	     System.out.println(sql);
       ResultSet result= con.createStatement().executeQuery(sql);
        
        while(result.next())
		{
        	data.add(new invoiceBin(result.getString(1),result.getString(2),result.getString(4),Double.parseDouble(result.getString(5)),Double.parseDouble(result.getString(6)),result.getString(7),Integer.parseInt(result.getString(8)),Double.parseDouble(result.getString(10)),result.getString(11),result.getString(12),Double.parseDouble(result.getString(13)),Double.parseDouble(result.getString(15)),Double.parseDouble(result.getString(16)),result.getString(17),Double.parseDouble(result.getString(18))));
		}
	    
	   
        return data;
		
	}
	
	public ArrayList<invoiceBin> searchbyCustNumber(int cust_number) throws SQLException {
		// TODO Auto-generated method stub
		 ArrayList<invoiceBin> data=new ArrayList<invoiceBin>();
			
			try {
	              Connection con=getCon();
				
				ResultSet result= con.createStatement().executeQuery(selectByCustNumber+cust_number);
				
				while(result.next())
				{
					data.add(new invoiceBin(result.getString(1),result.getString(2),result.getString(4),Double.parseDouble(result.getString(5)),Double.parseDouble(result.getString(6)),result.getString(7),Integer.parseInt(result.getString(8)),Double.parseDouble(result.getString(10)),result.getString(11),result.getString(12),Double.parseDouble(result.getString(13)),Double.parseDouble(result.getString(15)),Double.parseDouble(result.getString(16)),result.getString(17),Double.parseDouble(result.getString(18))));
				}
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return data;
	}

}
